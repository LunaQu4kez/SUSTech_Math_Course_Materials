function fty = odefun1( t,y )
fty = 2*y/(t+1)+(t+1)^2.5;
end