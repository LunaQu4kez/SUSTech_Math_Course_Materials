function f=odefun3(t,y)
f(1)=-0.01*y(1)-99.99*y(2);
f(2)=-100*y(2);
f=f(:);   %这样可保证f输出时为列向量
end 
