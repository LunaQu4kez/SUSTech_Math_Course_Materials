clc,clear
tic
options=odeset('AbsTol',1e-15,'RelTol',1e-12);
[x,y]=ode45('odefun2',[0,0.5],1,options);
toc
