clc,clear
mu=2;
[t,x]=ode45(@(t,x)odefun4(t,x,mu),[0,20],[1;0]);
plot(t,x(:,1),'-',t,x(:,2),'--');
title('Solution of Van der Pol Equation,/mu =2');
xlabel('time t');ylabel('solution x');
legend('x_1(y)','x_2(dy)');
