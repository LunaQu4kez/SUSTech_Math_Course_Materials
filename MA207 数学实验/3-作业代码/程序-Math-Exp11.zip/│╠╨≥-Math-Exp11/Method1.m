clear;close;
a=90;b=450;d=50;theta=pi/2;
[t,y]=ode45(@eg6_8fun,[0,0.1],[0 0],[],a,b,d,theta);
plot(y(:,1),y(:,2));
max(y(:,1)-d-a*t*cos(theta))
