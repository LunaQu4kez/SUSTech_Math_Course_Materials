function m=eg6_8c(a,b,d,theta,T)
[t,y]=ode45(@eg6_8fun,[0,T],[0 0],[],a,b,d,theta);
x=[d+a*t*cos(theta),a*t* sin(theta)];
n=length(t);j=n;
for i=1:n
    plot(x(i,1),x(i,2),'o',y(i,1),y(i,2),'r.');
    axis([0 max(x(:,1)) 0 max(x(:,2))]);hold on;
    m(i)=getframe;
    if y(i,1)>=x(i,1)
        j=i;
        break;
    end
end
hold off; movie(m);
if j<n
    hold on;
    plot(y(j,1),y(j,2),'rh','markersize',18);
    hold off;
    title(['导弹将在第',num2str(t(j)),'h击中敌舰']);
else
    title(['导弹在',num2str(T),'h内不能击中敌舰']);
end
end
