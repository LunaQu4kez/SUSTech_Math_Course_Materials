function xx=odefun5(t,x)
beta=8/3;rou=10;sig=28;
xx=[-beta*x(1)+x(2)*x(3);-rou*x(2)+rou*x(3);
-x(1)*x(2)+sig*x(2)-x(3)];
