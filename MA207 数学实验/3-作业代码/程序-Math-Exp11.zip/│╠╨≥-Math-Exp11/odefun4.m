function dxdt=odefun4(t,x,mu)
%mu = 2;
dxdt=zeros(2,1);
dxdt(1)=x(2);
dxdt(2)=mu*(1-x(1)^2)*x(2)-x(1);
%dxdt=dxdt(:);
end