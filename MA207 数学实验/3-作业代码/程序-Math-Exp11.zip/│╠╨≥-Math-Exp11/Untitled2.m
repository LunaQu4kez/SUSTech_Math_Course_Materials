clc,clear
odefun=@(t,y)y-2*t/y;
[t,y]=euler(odefun,[0,4],1,0.000001/2);
n=length(t);
e=sqrt(sum((sqrt(1+2*t)-y).^2)/n);
[n,e]


