clear;close;
a=90;b=450;d=50;theta=pi/2;
i=1;
for d=54:-1:36
for theta=0:0.1:pi,
[t,y]=ode45(@eg6_8fun,[0,0.1],[0 0],[],a,b,d,theta);
if max(y(:,1)-d-a*t*cos(theta))>0,
range(i,:)=[d,theta];
i=i+1;
break;
end
end
end
plot(range(:,1),range(:,2));
xlabel('d');ylabel('theta');
