function f=odefun2(x,y)
f=-2*y+2*x^2+2*x;
end