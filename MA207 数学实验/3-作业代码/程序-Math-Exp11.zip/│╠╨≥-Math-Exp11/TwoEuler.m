clc,clear
h=0.001/2;
t0=0;
tf=1;
t=t0:h:tf;
y_FE=t;
y_IE=t;
y_FE(1)=1;
y_IE(1)=1;
for k=1:length(t)-1
    z0 = odefun1( t(k),y_FE(k)  );
    y_FE(k+1) = y_FE(k) + h * z0 ;
    z1 = odefun1( t(k),y_IE(k)  );
    ynp1_bar = y_IE(k) + h*z1;
    z2 = odefun1( t(k+1), ynp1_bar );
    y_IE(k+1) = y_IE(k) + 0.5*h*( z1 + z2 );
end
y_EX = ( t + 1 ).^2 .* ( 2*(t+1).^1.5 + 1 )/3;
plot( t, y_FE, 'b--', 'LineWidth', 1.5 );
hold on
plot( t, y_IE, 'r:', 'LineWidth', 3);
plot(t,y_EX,'k-')

e_FE = sum( abs( y_FE - y_EX ) )*h;
e_IE = sum( abs( y_IE - y_EX ) )*h;
vpa( [e_FE; e_IE] )


