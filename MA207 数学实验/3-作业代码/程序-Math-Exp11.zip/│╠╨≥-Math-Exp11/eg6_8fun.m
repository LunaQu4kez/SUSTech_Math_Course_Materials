function dy=eg6_8fun(t,y,a,b,d,theta)
dydx=(a*t*sin(theta)-y(2)+1e-8)/...
    (abs(d+a *t*cos(theta)-y(1))+1e-8);
dy(1)=b/(1+dydx^2)^0.5;
dy(2)=b/(1+dydx^(-2))^0.5;
dy=dy(:);
end
