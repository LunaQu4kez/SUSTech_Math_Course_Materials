clc,clear
h=0.002;
t0=0;
tf=1;
t=t0:h:tf;
y_FE=t;
y_RK=t;
y_FE(1)=1;
y_RK(1)=1;
for k=1:length(t)-1
    y_FE(k+1) = y_FE(k) + h * odefun1( t(k),y_FE(k)  );
    K1 = odefun1( t(k),y_RK(k)  );
    K2 = odefun1( t(k)+0.5*h, y_RK(k) + 0.5*h*K1 );
    K3 = odefun1( t(k)+0.5*h, y_RK(k) + 0.5*h*K2 );
    K4 = odefun1( t(k)+h, y_RK(k) + h*K3 );
    y_RK(k+1) = y_RK(k) + (h/6)*( K1 + 2*K2 + 2*K3 + K4 );
end
y_EX = ( t + 1 ).^2 .* ( 2*(t+1).^1.5 + 1 )/3;
plot( t, y_FE, 'b--', 'LineWidth', 1.5 );
hold on
plot( t, y_RK, 'r:', 'LineWidth', 3);
plot(t,y_EX,'k-')


e_RK = abs( y_RK(end) - y_EX(end) );
vpa( e_RK )


