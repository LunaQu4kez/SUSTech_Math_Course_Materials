clc,clear;
tic;
[t,y]=ode45(@odefun3,[0,4],[2,1]);
toc
plot(t,y);

clear;tic;
[t,y]=ode15s(@odefun3,[0,4],[2,1]);
toc,plot(t,y);

