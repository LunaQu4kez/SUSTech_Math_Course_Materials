function Sn = Exp236_Sna(n,a)
Sn=sum( (1:n).^(-a) );
end