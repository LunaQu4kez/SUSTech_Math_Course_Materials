function Sn=Exp2_3_Sn(n)
Sn=sum(1./(1:n));
end