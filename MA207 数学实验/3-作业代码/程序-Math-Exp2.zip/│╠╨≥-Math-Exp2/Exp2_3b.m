clc,clear
N=500;
n=1:N;
Sn=zeros(size(n));
Sn(1)=1;
for k=2:N
    Sn(k)=Sn(k-1)+1/k;
end
a=-Sn(end)+log(N);
plot(n,Sn+a,'r--','LineWidth',2)
hold on
%plot(n,n,'r-')
plot(n,log(n),'b-')
