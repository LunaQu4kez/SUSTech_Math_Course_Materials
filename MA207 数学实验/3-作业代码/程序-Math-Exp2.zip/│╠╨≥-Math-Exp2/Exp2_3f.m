clc,clear
a=0.5;
N=500000;
n=1:N;
Sn=zeros(size(n));
Sn(1)=1;
for k=2:N
    Sn(k)=Sn(k-1)+k^(-a);
end
plot(n,Sn,'r--','LineWidth',2)
hold on
%plot(n,n,'r-')
%plot(n,n.^0.25,'b-')
