clc,clear
N=1000;
FN=zeros(1,N);
FN(1)=1;
FN(2)=1;
for k=3:N
    FN(k)=FN(k-1)+FN(k-2);
end
n=1:N;
%% conjecture
r=(sqrt(5)+1)/2;
br=(1-sqrt(5))/2;
eFN=(r.^n-br.^n)/sqrt(5);
Err=abs(FN-eFN)./FN;
plot(n,Err)
