clc,clear
N=50000;
n=1:N;
Sn=zeros(size(n));
Sn(1)=1;
for k=2:N
    Sn(k)=Sn(k-1)+1/k;
end
plot(n,Sn,'r*')
hold on
%plot(n,n,'r-')
plot(n,n.^0.25,'b-')
