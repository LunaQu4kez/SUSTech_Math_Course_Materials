clc,clear
a=0.5;
N=5000;
n=1:N;
Sn=zeros(size(n));
Sn(1)=1;
for k=2:N
    Sn(k)=Sn(k-1)+k^(-a);
end
Cn=Sn-n.^(1-a)/(1-a);
Dn=Sn-(n+1).^(1-a)/(1-a);
plot(n,Cn,'r--','LineWidth',2)
hold on
plot(n,Dn,'b-','LineWidth',2)
