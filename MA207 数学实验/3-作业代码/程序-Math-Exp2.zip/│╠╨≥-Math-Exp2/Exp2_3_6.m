clc,clear
a=0.5;
n=100000;
Sn=zeros(1,n);
Sn(1)=1;
for k=2:n
    Sn(k)=Sn(k-1)+k^(-a);
end

plot(1:n,Sn,'b--'), hold on

%Tn=(1:n).^(1-a)/(1-a);
%plot(1:n,Tn,'r-')



    