clc,clear
N=1e3;
n=1:N;
Sn=zeros(size(n));
Sn(1)=1;
for k=2:N
    Sn(k)=Sn(k-1)+1/k;
end
Dn=Sn-log(n+1);
plot(n,Dn,'r-','LineWidth',2)
hold on
Cn=Sn-log(n);
plot(n,Cn,'b-','LineWidth',2)


