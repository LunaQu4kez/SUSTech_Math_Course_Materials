function f=fun_exp21(x)
f=sin(x+cos(x));
end