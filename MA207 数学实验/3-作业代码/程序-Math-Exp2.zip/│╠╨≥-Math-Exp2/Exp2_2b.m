clc,clear
N=10000;
FN=zeros(1,N);
FN(1)=1;
FN(2)=1;
for k=3:N
    FN(k)=FN(k-1)+FN(k-2);
end
logFn=log(FN);
n=1:N;
plot(n,logFn,'-')