clc,clear
N=9;
n=1:N;
Sn=zeros(size(n));
Sn(1)=1;
for k=2:N
    Sn(k)=Sn(k-1)+1/k;
end
Dn=Sn-log(n+1);
plot(n,Dn,'r--','LineWidth',2)
%plot(n,Sn-log(n),'r--','LineWidth',2)
diffDn = diff(Dn);
temp=find(diffDn>0);
if (length(temp)==(N-1))
    disp('Method 1: increasing')
else
    disp('Method 1: not increasing')
end
sortDn=sort(Dn);
temp = norm(sortDn-Dn);
if (temp==0)
    disp('Method 2: increasing')
else
    disp('Method 2: not increasing')
end


