clc,clear
N=50;
FN=zeros(1,N);
for k=1:N
    FN(k)=Exp2_2_Fn(k);
end
plot(1:N,FN,'o-')