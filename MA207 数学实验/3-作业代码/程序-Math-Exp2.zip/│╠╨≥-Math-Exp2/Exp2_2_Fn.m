function F=Exp2_2_Fn(n)
if n<=0
    error('error in function Exp2_2_Fn: n<=0')
elseif n==1 || n==2
    F=1;
else
    F=Exp2_2_Fn(n-1)+Exp2_2_Fn(n-2);
end