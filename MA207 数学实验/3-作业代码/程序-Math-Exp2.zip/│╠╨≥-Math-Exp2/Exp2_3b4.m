clc,clear
n=1;
K=15;
df_S=zeros(1,K);
for k=1:K
    df_S(k) = Exp2_3_Sn(2^k*n)-Exp2_3_Sn(n);
end
plot( 1:K, df_S, '*-' )