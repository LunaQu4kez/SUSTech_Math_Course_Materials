function Exp14_1(c,a,b,M,K,n,cx,cy,zm)
%分形绘制程序—Julia集
%c为初始值,b*a为图像网格,M为阈值,K为颜色数，n是迭代次数,(cx,cy)是图像中心,zm是放缩倍数
delta=M/zm;
xl=cx-delta;
xr=cx+delta;
yd=cy-delta;
yu=cy+delta;
x=linspace(xl,xr,a);
y=linspace(yd,yu,b);
[X,Y]=meshgrid(x,y);
Z=X+Y*1i;
P=zeros(b,a);
C=c*ones(b,a);
for k=1:n
Z=Z.^2+C;
P(abs(Z)>M)=mod(k,K);
C(abs(Z)>M)=0;
Z(abs(Z)>M)=0;
end
imshow(255-P,[])
% only show those bounded points
%imagesc(P);
%colormap(jet)


