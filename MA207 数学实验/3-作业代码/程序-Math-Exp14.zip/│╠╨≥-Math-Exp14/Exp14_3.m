function Exp14_3(p,n)
%分形绘制程序—koch曲线、koch雪花
%p表示初始点，n表示三分次数，由于线段增长类型为指数型，实际使用时n不宜超过8
A=[cos(pi/3) sin(pi/3);-sin(pi/3) cos(pi/3)];
[s,t]=size(p);
m=s-1;
for k=1:n
    j=0;
    for i=1:m
        q1=p(i,:);
        q2=p(i+1,:);
        d=(q2-q1)/3;
        j=j+1;
        w(j,:)=q1;
        j=j+1;
        w(j,:)=q1+d;
        j=j+1;
        w(j,:)=q1+d+d*A;
        j=j+1;
        w(j,:)=q1+2*d;
    end
    m=4*m;
    p=[w;q2];
end
plot(p(:,1),p(:,2),'k')
axis off
