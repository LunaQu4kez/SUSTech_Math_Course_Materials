function P=Exp14_5(a,b,n)
%分形绘制程序—DLA分形生长模拟
%a(b表示生成网格，n表示迭代步数
P=zeros(a,b);
cx=round((a-1)/2);
cy=round((b-1)/2);
P(cx,cy)=1;
for i=1:n
    if mod(i,1000)==0
        i
    end
    [P,ss,tt]=funl1_5_input(P);%投放粒子
    con=1;
    while con==1
        [P,ss,tt,con]=funl1_5_seek(P,ss,tt);%周边查询
        if con==1
            [P,ss,tt,con]=fun11_5_move(P,ss,tt);%粒子移动
        end
    end
    P(:,b) =zeros(a,1);P(:,1)=zeros(a,1);P(1,:)=zeros(1,b);P(a,:)=zeros(1,b);
end
save P P
imshow(1- P,[]);
function [A,r,c]=funl1_5_input(A)
%粒子投入控制函数(exam11_5子函数)A表示图像矩阵，x表示投入点所在的行，c表示投入点所在的列
[s,t]=size(A);
p=rand;
q=rand;
if p<0.25
    m=ceil(q*s);
    A(m,1)=1;r=m;c=1;
elseif p>=0.25&p<0.5
    m=ceil(q*s);
    A(m,t)=1;r=m;c=1;
elseif p>=0.5&p<0.75
    m=ceil(q*t);
    A(1,m)=1;r=1;c=m;
else
    m=ceil(q*t);
    A(s,m)=1;r=s;c=m;
end
function[A,r,c,con]=fun11_5_move(A,x,y)
%粒子随机游动函数(子函数)
%A表示图像矩阵，x表示游动粒子所在的行，y表示游动粒子所在的列
[s,t]=size(A);
xy=[-1,0;1,0;0,-1;0,1];
rr=ceil(rand*4);
r=x+xy(rr,1);
c=y+xy(rr,2);
A(x,y)=0;
con=0;
if(r>=1&r<=s)&(c>=1&c<=t)
    con=1;
    A(r,c)=1;
end
function[A,xx,yy,con]=funl1_5_seek(A,x,y)
%查询游动粒子周围点是否存在粒子簇(子函数)
%A表示图像矩阵，x表示游动粒子所在的行，y表示游动粒子所在的列
[s,t]=size(A);
xy=[-1,0;1,0;0,-1;0,1];
k=1;
con=1;
while con==1&k<=4
    r=x+xy(k,1);
    c=y+xy(k,2);
    if(r>=1&r<=s)&(c>=1&c<=t)
        if A(r,c)==1
            con=0;
        end
    end
    k=k+1;
end
xx=x;yy=y;

