function Exp14_2(a,b,M,n,cx,cy,zm)
%分形绘制程序—Mandelbrot集
%b*a为图像网格,M为阈值,n是迭代次数,(cx，cy)是图像中心,zm是放缩倍数
delta=2/zm;
xl=cx-delta;
xr=cx+delta;
yd=cy-delta;
yu=cy+delta;
x=linspace(xl,xr,a);
y=linspace(yd,yu,b);
[X,Y]=meshgrid(x,y);
Z=X+Y*1i;
P=zeros(b,a);
C=Z;
for k=1:n
Z=Z.^2+C;
P(abs(Z)>M)=k;
Z(abs(Z)>M)=0;
C(abs(Z)>M)=0;
end
imshow(P,[])

