function Exp14_4(p,theta,n)
%分形绘制程序一分形树枝stheta表示生长角度，n表示生长次数，由于线段增长类型为指数型，实际使用时n不宜超过7
m=2;
plot(p(:,1),p(:,2),'k')
hold on
A=[cos(theta) sin(theta);-sin(theta) cos(theta)];
for k=1:n
i=1;
for j=1:2:m
p1=p(j,:);
p2=p(j+1,:);
d=(p2-p1)/3;
w(i,:)=p1;
i=i+1;q1=p1+d;w(i,:)=q1;
i=i+1;w(i,:)=q1;i=i+1;q2=q1+d*A;w(i,:)=q2;
i=i+1;w(i,:)=q1;i=i+1;q3=p1+2*d;w(i,:)=q3;
i=i+1;w(i,:)=q3;i=i+1;q4=q3+d*A';w(i,:)=q4;i=i+1;w(i,:)=q3;
i=i+1;w(i,:)=p2;i=i+1;point=[q1;q2];%新生成点，添加绘图线
plot(point(:,1),point(:,2),'k');
point=[q3;q4];%新生成点，添加绘图线
plot(point(:,1),point(:,2),'k');
end
p=w;
m=5*m;
end
axis off
