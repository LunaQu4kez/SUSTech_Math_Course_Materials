clc,clear
syms d p v1 v2 v3 G

assume(d,'positive')
assume(p,'positive')
assume(G,'positive')

DOS=5;

G2=G/(G-1);
dh = d + G2*p;
vsq=v1*v1+v2*v2+v3*v3;
W=1/sqrt(1-vsq);
Wsq= 1/(1-vsq);
D=d*W;
m1=dh * Wsq * v1;
m2=dh * Wsq * v2;
m3=dh * Wsq * v3;
E=dh*Wsq-p;

V=[d,v1,v2,v3,p];
U=[D,m1,m2,m3,E];

s=log(p)-G*log(d);

PUPV=zeros(DOS,DOS)+d-d;
for i=1:DOS
    for j=1:DOS
        PUPV(i,j)=simplify( diff(U(i), V(j)) );
    end
end

PVPU = simplify( inv(PUPV) );

PsPV = zeros(1,DOS) + d-d;
for j=1:DOS
    PsPV(j)=simplify( diff(s,V(j)) );
end
PsPU = simplify( PsPV * PVPU );

PDPV = zeros(1,DOS) + d-d;
for j=1:DOS
    PDPV(j)=simplify( diff(D,V(j)) );
end
PDPU = simplify( PDPV * PVPU );

P2sPUPV = zeros(DOS,DOS) + d-d;
for i=1:DOS
    for j=1:DOS
        P2sPUPV(i,j) = simplify( diff( PsPU(i), V(j) ) );
    end
end
P2sP2U = simplify( P2sPUPV * PVPU );

P2DPUPV = zeros(DOS,DOS) + d-d;
for i=1:DOS
    for j=1:DOS
        P2DPUPV(i,j) = simplify( diff( PDPU(i), V(j) ) );
    end
end
P2DP2U = simplify( P2DPUPV * PVPU );

R=1/G;
P2entrP2U = zeros(DOS,DOS)+d-d;

for i=1:DOS
    for j=1:DOS
        P2entrP2U(i,j) = simplify( -PDPU(i)*PsPU(j)-PDPU(j)*PsPU(i)-D*P2sP2U(i,j)-D*R*PsPU(i)*PsPU(j) );
    end
end

nA1=P2entrP2U







