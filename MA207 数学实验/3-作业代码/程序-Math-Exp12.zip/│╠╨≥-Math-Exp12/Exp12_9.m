clc,clear
p=0.04; n=10;     %设定产品的档次，抽样次数。
         for k=1:n               %抽样n次。
            r(k)=rand(1,1);   %产生随机数。
            if r(k)<=p
               x(k)=1;           %抽样得到废品。    
             elseif r(k)>p
              x(k)=0;            %抽样得到正品 。   
            end
         end
I=[1:n];
[I;x] 