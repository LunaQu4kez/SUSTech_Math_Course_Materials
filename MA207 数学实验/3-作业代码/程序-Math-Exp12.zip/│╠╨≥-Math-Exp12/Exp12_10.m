clear,clf,n=50;
p=0.04;
rand('seed',1),r=rand(1,n);
k=+find(r<=p);
x=zeros(1,n);
x(k)=ones(1,length(k));
p_estimate=sum(x)/n;
t=[0.01 0.02 0.03 0.04 0.05 0.06];
%t=linspace(0.01,0.5,40)
Lt=t.^sum(x).*(1-t).^(n-sum(x));
%lnLt=sum(x)*log(t)+(n-sum(x))*log(1-t);
set(gca,'fontsize',16),
plot(t,Lt,'o:'),
[Lmax,I]=max(Lt);
tmax=t(I);
text(t(I),Lmax,['\fontsize{16}\leftarrow\it Lmax=' ,num2str(Lmax)])
text(t(I),0.95*Lmax,['\fontsize{16}\it{ at  p}= ',num2str(tmax)])
xlabel('p','fontsize',16);ylabel('L(p)','fontsize',16);