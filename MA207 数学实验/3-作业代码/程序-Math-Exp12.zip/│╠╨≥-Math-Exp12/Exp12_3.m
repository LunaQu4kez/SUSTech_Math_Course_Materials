clc,clear
n=5;p=0.5; m=5000; 
rand('seed',5); R = binornd(n,p,1,m);   %模拟投球。
f=[5, 1, 0.2, 0.2, 1, 5]; %奖品的价值向量。
s=0;                          
for k=1:n+1                                         %计算第0～n格奖品价值。
   u=find(R==(k-1));   %计算落入第k-1格的小球下标，并存于向量u中。
   s=s+f(k)*length(u); %计算相应的奖品价值，并存于向量s中。   
end
mean_return=s/m  %计算一次抽奖的平均回报 。
