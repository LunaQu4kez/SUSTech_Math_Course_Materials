clc,clear
n=5;p=0.5;
m=5000;
rand('seed',3);
R=binornd(n,p,1,m);%模拟二项分布的随机数，相当于模拟投球m次
for I=1:(n+1)
    k=find(R==(I-1));
    h(I)=length(k)/m;
end
x=0:5;
bar(x,h),axis([-1 6 0 1]); %画频率图

