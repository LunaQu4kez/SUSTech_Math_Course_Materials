 clear,clc,clf,n=100;
 x=normrnd(170,4.5,1,n);
y=0.36*x+normrnd(0,0.1,1,n);
[b,bint,r,rint,stats] = regress(y',[ones(100,1) x']);
b,bint,stats
rcoplot(r,rint),set(gca,'fontsize',15) 