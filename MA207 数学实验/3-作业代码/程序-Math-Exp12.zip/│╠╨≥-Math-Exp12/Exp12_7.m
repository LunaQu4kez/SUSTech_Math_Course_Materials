 clear,clf,n=1000;m=15;x=normrnd(170,4.5,1,n);
y=0.36*x+normrnd(0,7,1,n);a=min(x);b=max(x);c=min(y);d=max(y);
h1=(b-a)/m;h2=(d-c)/m;
xx=linspace(a-h1,b+h1,m);yy=linspace(c-h2,d+h2,m);
[X,Y]=meshgrid(xx,yy);
for k=1:m             %计算频数。
 for l=1:m
     j=find(x>=(X(k,l)-h1)&x<=(X(k,l)+h1));
     h=find(y(j)>=(Y(k,l)-h2)&y(j)<=(Y(k,l)+h2));
   z(k,l)=length(h)/n;
end
end  
mu=[170 0.36*170];              %计算二维正态分布密度。
C=[4.5^2 0.36*4.5^2; 0.36*4.5^2, (0.36*4.5)^2+7^2];
detC=det(C);
for k=1:m
 for l=1:m
   u=[X(k,l),Y(k,l)]'-mu';s=2*pi*sqrt(detC);
   z1(k,l)=s^-1*exp((-0.5)*u'*C^-1*u);
end
end  
subplot(2,2,1),surf(X,Y,z),axis([a b c d 0 0.15]),
set(gca,'fontsize',15);
subplot(2,2,2),contour(X,Y,z),axis([a b c d ]),axis('equal'),
subplot(2,2,3),surf(X,Y,z1),axis([a b c d 0 0.005]),
subplot(2,2,4),contour(X,Y,z1),axis([a b c d ]),axis('equal')