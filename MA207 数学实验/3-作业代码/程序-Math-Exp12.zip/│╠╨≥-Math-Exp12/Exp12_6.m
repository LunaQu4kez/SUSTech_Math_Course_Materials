clear,clc,clf
n=1000;x=normrnd(170,4.5,1,n);
y=0.36*x+normrnd(0,7,1,n);
a=min(x);b=max(x);c=min(y);d=max(y);xx=linspace(a,b,20);
yy=0.36*xx;plot(x,y,'ko'),hold on,
plot(xx,yy,'k-','linewidth',5),grid,
axis([a b c d]),axis('equal'),
xlabel('身高X');ylabel('体重Y'); 