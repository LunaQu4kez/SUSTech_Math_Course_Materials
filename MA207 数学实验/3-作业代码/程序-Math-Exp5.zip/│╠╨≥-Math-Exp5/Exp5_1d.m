clc,clear
N=1e6;
s=0;
for k=1:N
    rax=2*rand-1;
    ray=2*rand-1;
    raz=2*rand-1;
    rax=rax^2;
    ray=ray^2;
    raz=raz^2;
    if ( rax+ray<=1 )...
            && (rax+raz<=1)...
            && (ray+raz<=1)
        s=s+1;
    end
end
s = 8*s/N;
vpa(s)
s_ex = 16 - 8*2^(1/2);
vpa(s_ex)