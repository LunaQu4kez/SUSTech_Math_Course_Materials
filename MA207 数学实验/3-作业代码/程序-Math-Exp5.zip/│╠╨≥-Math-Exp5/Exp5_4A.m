function flag=Exp5_4A(a,b)
x=factor(a);
y=factor(b);
flag = 0;
if isempty(intersect(x,y))
    flag = 1;
end
end
