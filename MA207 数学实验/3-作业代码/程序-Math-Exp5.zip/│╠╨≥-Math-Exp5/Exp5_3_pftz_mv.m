clc,clear
n=1e6;
hold off
a=1;% the distance between the two parallel lines
l=0.6;% the length of the needle 
counter=0;% counter, to count times of intersection
%n=10000000;% times of throw
m=inputdlg('��������ӻ�ʵ�����m','��������ӻ�ʵ�����m',1,{'20'});  
m=str2num(m{1});%times of throw which we can see
%m=20;%times of throw which we can see
x=unifrnd(0,a/2,1,n);% uniform random number generator, to generate n
% random numbers between 0 and a/2, which is the
% distance between the middle of the needle and the
% nearest parallel line.
phi=unifrnd(0,pi,1,n);% to generate n random numbers between 0 and pi,
% which is the angle between the needle and the
% nearest parallel line.
axis off
%title('�ѷ�Ͷ��ʵ��','fontsize',30)
for k=0:10
    hold on,
    plot([0 10],[k k],'k')
end
k=1;
%���ÿ��ӻ�����
while k<=m;
    clear sgn b x0 y0 
    sgn=-1;
    b=randi(9,1,1);
    if rand<0.5
        sgn=1;
    end 
    x0=8*rand+1;
    y0=x(1,k)*sgn+b;                                                                                                                                           
    xy=-l/2:l:l/2;
    x1=x0+xy*cos(phi(1,k));
    y1=y0+xy*sin(phi(1,k));
    hold on,
    plot(x1,y1,'r')
    pause(1)
    k=k+1;
end
%����Ͷ�������ཻ�Ĵ���
for i=1:n
if x(i)<l*sin(phi(i))/2 % if the generated x is smaller than l*sin(phi(i))/2, intersect.
counter=counter+1;
end
end
frequency=counter/n; % to calucate the frequency of intersection
zz=2*l/(a*frequency) % get the value of pi from the frequency