clc,clear
N=1e4;
n=1e7;
tic
m=0;
for k=1:n
    rai=randi(N,1,2);
    flag=Exp5_4B(rai(1),rai(2));
    m = m + flag;
end
p=m/n;
toc
vpa( sqrt(6/p) )