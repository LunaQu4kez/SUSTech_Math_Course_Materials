function flag=Exp5_4B(a,b)
if a < b
    tmp = a;
    a = b;
    b = tmp;
end
while 1
    c = mod(a,b);
    if c==0
        break
    else
        a = b;
        b = c;
    end
end
flag = 0;
if b==1
    flag = 1;
end

