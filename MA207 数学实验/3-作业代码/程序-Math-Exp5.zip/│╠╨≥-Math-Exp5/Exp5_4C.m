function flag=Exp5_4C(a,b)
c=gcd(a,b);
if c==1
    flag = 1;
else
    flag = 0;
end

