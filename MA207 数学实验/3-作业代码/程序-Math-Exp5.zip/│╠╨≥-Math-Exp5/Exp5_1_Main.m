clc,clear
N=[1:10]*1000;
for k=1:length(N)
    n=N(k);
    [err0,app_pi0] = Exp5_1(n);
    err(k)=err0;
    app_pi(k)=app_pi0;
end
loglog(N,err,'*-')