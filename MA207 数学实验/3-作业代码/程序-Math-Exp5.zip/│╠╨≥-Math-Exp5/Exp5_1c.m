function [err,app_pi] = Exp5_1c(n)
app_pi = 0;
for k=1:n
    tmp = 1;
    if mod(k,2)==0
        tmp=-1;
    end
    tmp2 = 4*0.2^(2*k-1)-(1/239)^(2*k-1);
    app_pi = app_pi + tmp*tmp2/(2*k-1);
end
app_pi = app_pi*4;
err=abs(app_pi - pi);