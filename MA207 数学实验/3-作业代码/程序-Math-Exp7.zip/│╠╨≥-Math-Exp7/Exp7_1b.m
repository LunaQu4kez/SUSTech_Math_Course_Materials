clc,clear
a(1)=0;
b(1)=1;
h=1;
k=1;
fL=Exp7_1f( a(1) );
fR=Exp7_1f( b(1) );
while h>=1e-20 %&& k<10000
    xk=(a(k)+b(k))/2;
    fk = Exp7_1f(xk);
    if fL*fk<0
        a(k+1)=a(k);
        b(k+1)=xk;
    else
        a(k+1)=xk;
        b(k+1)=b(k);
    end
    k=k+1;
    k
    h=h/2;
    %h=b(k)-a(k);
    %vpa(h)
end
xk=(a(k)+b(k))/2;

    
    