function y=Exp7_1f(x)
y=x^3+x-1;
end