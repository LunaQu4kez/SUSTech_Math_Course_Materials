function y=Exp7_3f(x,s)
if s==1
   y=(4-x.*x);
elseif s==2
   y=4./(1+x);
elseif s==3
   y=x-(x.^2+x-4)./(2*x+1);
end 