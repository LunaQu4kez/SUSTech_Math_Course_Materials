function x=Exp7_6(xx,n)
%牛顿迭代法,xx为迭代初值,n为迭代步数
x=zeros(1,n+1);
x(1)=xx;
for i=1:n
x(i+1)=x(i)-(x(i)^3+x(i)-1)/(3*x(i)^2+1);
end
