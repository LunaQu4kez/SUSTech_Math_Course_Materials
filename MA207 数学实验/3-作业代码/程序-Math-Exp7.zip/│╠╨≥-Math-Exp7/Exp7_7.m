function[y,k]=Exp7_7(er,n,xa,xb)
%两点弦截法，er表示误差，n表示步数，xa、xb表示迭代初值，%y为向量，其分量表示在迭代过程中的各个点，
%k表示实际迭代步数
syms x xk
x0=xa;x1=xb;
ff=x^3-3*x-1;
y(1)=xa;y(2)=xb;
k=2;
while abs(x1-x0)>er&k<n
    fx1=subs(ff,x,x1);
    fx0=subs(ff,x,x0);
    x2=x1-fx1*(x1-x0)/(fx1-fx0);
    k=k+1;
    y(k)=x2;
    x0=x1;
    x1=x2;
end
