clear,clf,n0=100;n=150;
x0=0.1;hold on,s=[];xx=[];
for r=2.6:0.002:4
%for r=0:0.3:4
   x(1)=x0;                                %初值
   for j=2:n
      x(j)=r*x(j-1)*(1-x(j-1));                    %迭代
   end   
   s=[r*ones(1,n+1-n0);s];          %在固定的r处画出n以后的迭代值xn,xn+1，…     
   xx=[x(n0:n);xx];   xs=max(x(n0:n));
   %text(r-0.1,xs+0.05,['\it{r}=',num2str(r)])    %标注
end 
plot(s,xx,'k.','markersize',15);        %调整点的大小获得较好的视觉效果
%plot(s,xx,'k.','markersize',1);   xlabel('参数r'),   ylabel('迭代序列x')   