%  绘制迭代的蛛网图(对问题3的三个函数)
clf,clear
 s=3;            %  选择函数：s=1、2、3时分别对应函数f1、f2、f3
if s==1         %对于函数f1,决定坐标轴的范围。(以便得到较好的图形显示效果)   
   a=-5;b=5;      
   x00=2.1;y00=0;          %初始点
   x=linspace(a,b,80);   y0=x;    y1=zxy7_3f(x,s);
   c=-(1+0.3)*max(abs(y1));d=(1+0.3)*max(abs(y1));
elseif s==2|s==3       %对于函数f1,决定坐标轴的范围，将函数限制在同一范围内   a=0;b=5;                  %显示，以便进行观察和比较
a=0;b=5;
    x00=4;y00=0;           %初始点 
   x=linspace(a,b,80);
   y0=x;                    %计算直线y=x 
   y1=Exp7_3f(x,s);    %计算曲线y=f(x)
   c=0;d=max((1+0.3)*max(abs(y1)),5.2);
end
clear y;
y=[y0;y1];
plot(x,y,'linewidth',2),hold on,    % 画图 legend('y=x','y=f2'),
plot([a b],[0,0],'k-',[0 0],[c d],'k-'),axis([a,b,c,d]),     % 画坐标轴
z=[];          
for i=1:10                                 % 画蛛网图，迭代过程为n=10次    
   xt(1)=x00; yt(1)=y00;             %决定始点坐标
   xt(2)=Exp7_3f(xt(1),s); yt(2)=Exp7_3f(xt(1),s);       %决定终点坐标
   Expplot7_3(xt,yt,0.6)              % 画蛛网图     
   if i<=5
      pause                       % 按任意键逐次观察前5次迭代的蛛网图
   end
   x00=xt(2); y00=yt(2);   % 将本次迭代的终点作为下一次迭代的起点。
   z=[z,xt(1)];                 %保存迭代点
end                      