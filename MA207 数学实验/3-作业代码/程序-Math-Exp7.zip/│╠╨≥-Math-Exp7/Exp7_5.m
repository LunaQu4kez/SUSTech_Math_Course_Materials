clf
r=2.7;  n=15; %r=3.2;r=3.9; n=15;
x00=0.2;y00=0;a=0;b=1;x=linspace(a,b,50);
plot(x,x),axis([a b a b]),hold on,theaxes=axis;
y=r*x.*(1-x);
plot(x,y),
z=[];
for i=1:n          
   xt(1)=x00; yt(1)=y00;
   xt(2)=r*xt(1).*(1-xt(1)); yt(2)=xt(2);
   Expplot7_3(xt,yt,0.6)
   %annotation('doublearrow',xt,yt) 
   
   x00=xt(2); y00=yt(2);
   z=[z,xt(2)];
end 