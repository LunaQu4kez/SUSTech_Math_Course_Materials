clc,clf,clear
A=[0 1 1 0;0 0 1 1;0 0 0 1;1 0 0 0];  
xy=[0 1;0 0;-1 -0.5;1 -0.5];
graphy_plot(A,xy,1,0.5),  % gplot(A,xy) 