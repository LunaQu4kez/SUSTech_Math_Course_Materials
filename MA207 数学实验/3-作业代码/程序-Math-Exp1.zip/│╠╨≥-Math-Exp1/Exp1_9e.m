clc,clear
[X,Y,Z]=peaks(100);%peaksΪMATLAB�Զ��庯��

subplot(2,2,1)
hf=surf(X,Y,Z); colormap(jet);colorbar
set(hf,'EdgeColor','none')
subplot(2,2,2)
contour(X,Y,Z,10); colormap(jet);colorbar
subplot(2,2,3)
contourf(X,Y,Z,10); colormap(jet);colorbar
subplot(2,2,4)
pcolor(X,Y,Z);shading('interp');h=colormap(jet(4096));colorbar
