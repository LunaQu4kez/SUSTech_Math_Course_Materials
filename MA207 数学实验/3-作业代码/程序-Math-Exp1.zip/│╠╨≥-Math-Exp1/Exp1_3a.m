clc,clear
x=-1:0.0001:1;
y=sin(1./x);
plot(x,y)