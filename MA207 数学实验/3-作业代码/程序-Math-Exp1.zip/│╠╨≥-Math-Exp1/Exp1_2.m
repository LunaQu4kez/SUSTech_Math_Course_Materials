x=0:0.01:10*pi;
y=zeros(size(x));
m=2000;
for ii=1:length(y)
    k=1:m;
    y(ii)=sum( sin( x(ii)*( 2*k-1 ) )./(2*k-1) );
end
plot(x,y)
Fs=8192;
sound(y,Fs/8)