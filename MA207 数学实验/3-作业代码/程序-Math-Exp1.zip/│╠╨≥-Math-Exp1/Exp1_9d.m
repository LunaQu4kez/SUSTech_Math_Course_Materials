clc,clear
[X,Y,Z]=peaks(30);%peaksΪMATLAB�Զ��庯��
subplot(2,3,1);
surf(X,Y,Z);colormap(jet);
title('surf of peaks(30)');
subplot(2,3,2);
meshc(X,Y,Z);colormap(jet);
title('meshc of peaks(30)');
subplot(2,3,3);
contour(X,Y,Z,15);colormap(jet);
title('contour of peaks');
subplot(2,3,4);
contourf(X,Y,Z,15);colormap(jet);
title('contourf of peaks');
subplot(2,3,5);
contour3(X,Y,Z,10);colormap(jet);
title('contour3 of peaks');
subplot(2,3,6);
C=contour(X,Y,Z,5);colormap(jet);
clabel(C);
title('clabel of peaks');