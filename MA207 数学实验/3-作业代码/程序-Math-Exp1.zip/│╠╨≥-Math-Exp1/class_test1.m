clc,clear
x=10*rand(1000,1);
y=10.^x.*(1+0.2*rand(1000,1));

semilogy(x,y,'.')
