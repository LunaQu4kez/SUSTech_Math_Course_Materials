clc,clear,clf 
t=0:0.1:3*pi;alpha=0:0.1:3*pi;
plot(t,sin(t),'r-');hold on;  plot(alpha,3*exp(-0.5*alpha),'k:');
 set(gca,'fontsize',15,'fontname','times New Roman'),     
xlabel('\it{t(deg)}');
ylabel('\it{magnitude}');
title(' \it{sine wave and {\it{Ae}}^{-\alpha{\itt}}wave}'); 
text(6,sin(6),'\fontsize{15}The Value \it{sin(t)} at {\itt}=6\rightarrow\bullet', 'HorizontalAlignment','right'),
text(2,3*exp(-0.5*2),...
['\fontsize{15}\bullet\leftarrow The Value of \it{3e}^{-0.5 \it{t}}=',...
num2str(3*exp(-0.5*2)),' at \it{t} =2 ']);
legend('\itsin(t)','{\itAe}^{-\alphat}')  
