clc,clear
vx = 40;
t = 0:0.01:10;
%N=length(t);
%P=randperm(N);
x = vx*t;
y = -9.8*t.^2/2;
comet(x,y)