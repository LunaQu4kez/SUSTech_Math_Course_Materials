clc,clear
x=-8:0.5:8;
y=x;
[X,Y]=meshgrid(x,y);
R=sqrt(X.^2+Y.^2)+eps; %˼��ΪʲôҪ��eps?
Z=sin(R)./R;


subplot(1,2,1)
mesh(X,Y,Z); %����meshz,  meshc�ڴ��滻֮
colormap(jet);
%colorbar

subplot(1,2,2)
surf(X,Y,Z);
colormap(jet);
