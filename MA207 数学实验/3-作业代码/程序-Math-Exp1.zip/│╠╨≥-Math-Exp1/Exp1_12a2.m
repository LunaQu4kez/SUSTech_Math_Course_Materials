theta = 0:0.0001:2*pi;
r = 10;
figure, axis equal, axis([-r r -r r]), hold on
x=r*cos(theta);
y=r*sin(theta);
comet(x,y)


