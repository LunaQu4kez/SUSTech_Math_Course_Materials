clc,clear,clf
x=linspace(0,8*pi,100);
y1=sin(x+cos(x+sin(x)));   y2=0.2*x+sin(x+cos(x+sin(x)));
plot(x,y1,'k:',x,y2,'k-');  
legend('sin(x+cos(x+sin(x))','0.2x+sin(x+cos(x+sin(x)))')
