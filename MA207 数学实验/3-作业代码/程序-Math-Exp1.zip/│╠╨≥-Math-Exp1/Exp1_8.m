subplot(4,2,1);%����
x=1:10;y=round(10*rand(1,10));
bar(x,y);title('bar');axis tight
subplot(4,2,2);%����ͼ
x=0:pi/10:2*pi;y=x.*sin(x);
feather(x,y);title('feather');
subplot(4,2,3); %ͳ��ֱ��ͼ
x=-2.9:0.1:2.9;y =randn(10000,1);
hist(y,x);title('hist');
subplot(4,2,4);%��ͼ
pie([2 4 3 5],[1 1 0 0],{'North','South','East','West'});title('pie');
subplot(4,2,5);%����ͼ
x=0:pi/20:2*pi;y=exp(-x/8).*sin(x);
stem(x,y);title('stem');
subplot(4,2,6); %ʸ��ͼ
[x,y]=meshgrid(-2:.2:2,-1:.15:1);
z=x.*exp(-x.^2-y.^2);[px,py]=gradient(z,.2,.15);
contour(x,y,z),hold on
quiver(x,y,px,py),hold off,title('quiver');
subplot(4,2,7); %��������ͼ(ͼ1-19-(g))
x=1:10;
y=[0,1,-1,1,1,0,-1,-1,1,0];
fill(x,y,'b');title('fill');
subplot(4,2,8);%�������ͼ(ͼ1-19-(h))
t=linspace(0,2*pi,12);
x=sin(2*t);y=cos(2*t);
area(x,y,'facecolor','b');title('area');



