subplot(1,2,1);
th=0:pi/200:2*pi;
rh=2*(1-cos(th));
polar(th,rh,'k')
title('r=2(1-cos(\theta))');
subplot(1,2,2);
th=0:pi/500:2*pi;
rh=3*cos(4*th);
polar(th,rh,'k')
grid off
axis off
title('r=3cos(4\theta)');
