clear;clc
[x,y]=meshgrid(linspace(-2,2,200),linspace(-2,2,200));
fx = x+y-x.*( x.^2+y.^2 );
fy = -x+y-y.*(x.^2+y.^2);

% for k1=1:200
%     for k2=1:200
%         if ( x(k1,k2) )^2 + ( y(k1,k2) )^2 <1
%             fx(k1,k2)=0;
%             fy(k1,k2)=0;
%         end
%     end
% end

h=streamslice(x,y,fx,fy,1.5);
%set(0,'DefaultTextInterpreter', 'latex')
set(h,'LineWidth',1,'Color','b')
axis equal 
axis([-2 2 -2 2])
h=xlabel('$x$');set(h,'Interpreter','latex','fontsize',14)
h=ylabel('$y$');set(h,'Interpreter','latex','fontsize',14)

set(gca,'FontSize',13)
set(gca,...
    'XTick',-2:1:2,'TickLabelInterpreter', 'latex','YTick',-2:1:2)
box on

print -depsc2 save_eps_example.eps;
