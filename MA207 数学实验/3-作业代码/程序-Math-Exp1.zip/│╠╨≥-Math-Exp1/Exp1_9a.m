clc,clear
a=-0.98;b=0.98;c=-1;d=1;n=10;
x=linspace(a,b,n); y=linspace(c,d,n);
[X,Y]=meshgrid(x,y);
plot(X,Y,'+')
