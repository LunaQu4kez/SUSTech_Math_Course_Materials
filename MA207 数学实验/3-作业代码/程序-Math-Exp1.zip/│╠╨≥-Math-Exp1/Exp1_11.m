clc,clear
a=-20;
[x,y]=meshgrid(-10:0.2:10);  
z1=x.^2-2*y.^2;     %�����溯��
z2=a*ones(size(x));   %ƽ�� 


figure('Color',[0.68 0.92 1])
mesh(x,y,z1);
hold on;
mesh(x,y,z2);  


%������
x0=-10:0.1:10;
y0=sqrt(0.5*(x0.^2-a));
z0=a*ones(size(x0));
plot3(x0,y0,z0,'k','LineWidth',3)
plot3(x0,-y0,z0,'k','LineWidth',3)

v=[-10 10 -10 10 -100 100]; 
axis(v)
box on
view([-67.5, 50]);

