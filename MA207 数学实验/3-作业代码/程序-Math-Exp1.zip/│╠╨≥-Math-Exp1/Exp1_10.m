clf,  t=linspace(0,1.5,20);%:0.1:1.5;
x=t.^2;y=(2/3)*t.^3;z=(6/4)*t.^4-(1/3)*t.^3; 
Vx=2*t;Vy=2*t.^2;Vz=6*t.^3-t.^2;
plot3(x,y,z,'r.-','linewidth',1,'markersize',10),hold on   
h=quiver3(x,y,z,Vx,Vy,Vz);set(h,'linewidth',1),grid on 
xlabel('x'),ylabel('y'),zlabel('z')
box on 
