subplot(1,2,1);
x=rand(1,30)*10;
b=rand(1,30);
y=x+b;
h=scatter(x,y,20,'o');
set(h,'MarkerFaceColor', 'r','MarkerEdgeColor','r')
title('scatter');
subplot(1,2,2);
t=0:pi/100:10*pi;
x=5*t.*cos(t);
y=5*t.*sin(t);
z=2*t;
scatter3(x,y,z,20,'o')
title('scatter3');
