clc,clear
k=1:3000;
x=1./k;
y=sin(k);
plot(x,y,'.')
axis([0,0.004,-1,1])
hold on
plot( x(3:44:end),y(3:44:end),'r-' )
%plot( x(4:355*2:end),y(4:355*2:end),'b-' )