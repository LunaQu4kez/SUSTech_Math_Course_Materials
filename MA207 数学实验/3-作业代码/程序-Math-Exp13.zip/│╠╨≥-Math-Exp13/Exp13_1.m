clc;clear all;close all;
global L Li N;
%%%%%初始化参数%%%%%
e=0.01;%计算精度
lb=[0;0];ub=[10;5];%变量取值范围
Li=ceil(log2((ub-lb)./e));
L=sum(Li);%变量字串长度
N=500;%群体规模
T=300;%最大遗传代数
pc=0.9;pm=0.05;%交叉和变异概率
%%%%%初始种群%%%%%
population=round(rand(N,L));%初始种群,二进制编码
[xx,fitness]=decode(population,lb,ub);%解码，计算适应度
[optfit,indmax]=max(fitness);%初始种群最佳个体
best=population(indmax,:);%初始种群最优染色体
optx=xx(indmax,:);%初始种群最优变量值
fitcurve(1)=optfit;%第1代最优适应度
%%%%%迭代求解%%%%%
for ii=1:T
    ii
    population=selection(population,best,fitness);%选择
    population=crossover(population,best,pc);%交叉
    population=mutation(population,pm);%变异
    [xx,fitness]=decode(population,lb,ub);%解码，计算适应度
    [fmax,indmax]=max(fitness);%当代最佳个体
    if fmax>=optfit
        best=population(indmax,:);%到目前为止最优染色体
        optx=xx(indmax,:);%到目前为止最优变量值
        optfit=fmax;%到目前为止最优适应度
    end
    fitcurve(ii+1)=optfit;%存储每代的最优适应度
end
%%%%%计算结果输出%%%%%%
plot(0:T,fitcurve);%绘制最优适应度进化曲线
title('最优适应度曲线');xlabel('遗传代数');ylabel('最优适应度')
optx %输出最优变量值
optfit %输出最优适应度值


%%%%%解码子函数%%%%%
function[xx,fitness]=decode(population,lb,ub)
global Li N;
for i=1:N
    for k=1:length(Li) %二进制化为十进制
        s(k)=0;
        for j=1:Li(k)
            s(k)=s(k)+population(i,sum(Li(1:k))-j+1)*2^(j-1);
        end
        x(k)=(ub(k)-lb(k))*s(k)/(2^Li(k)-1)+lb(k);%映射到取值范围内
    end
    fitness(i)=fitnessfcn(x);
    xx(i,:)=x;
end
end


%%%%%选择子函数%%%%%
function population=selection(population,best,fitness)
global N;
p=fitness./sum(fitness);
q=cumsum(p);
for i=1:(N-1)
    r=rand;
    tmp=find(r<=q);
    newpopulation(i,:)=population(tmp(1),:);
end
newpopulation(N,:)=best;%最优保留
population=newpopulation;
end
%%%%%交叉子函数%%%%%
function population =crossover(population,best,pc)
global L N;
for i=1:2:(N-1)
    cc=rand;
    if cc<pc
        point=1+ceil(rand*(L-2));%取得一个2到L-1的整数
        ch=population(i,:);
        population(i,point+1:L)=population(i+1,point+1:L);
        population(i+1,point+1:L)=ch(1,point+1:L);
    end
end
population(N,:)=best;%最优保留
end
%%%%%变异子函数%%%%%
function population=mutation(population,pm)
global L N;
mm=rand(N,L)<pm;%N行,小于变异概率的赋值为1,其他赋值0
mm(N,:)=zeros(1,L);%最优保留，不变异
population(mm)=1-population(mm);%变异发生
end
%%%%%适应度函数%%%%%
function y=fitnessfcn(x)
y=20+x(1)^2+x(2)^2-10*(cos(2*pi*x(1))+cos(2*pi*x(2)));
end

