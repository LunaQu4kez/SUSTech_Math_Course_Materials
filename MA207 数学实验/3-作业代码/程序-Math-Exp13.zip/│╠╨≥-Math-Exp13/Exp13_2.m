clc,clear;close all;rng default;
x=-3:0.3:1.8;y=-2:0.2:1.2;xy=[x;y];%输入数据
z=[0.6589,0.2206,-0.1635,-0.4712,-0.6858,-0.7975,-0.8040,...
-0.7113,-0.5326,-0.2875,0,0.3035, 0.5966,...
0.8553,1.0600,1.1975,1.2618];%输出数据
net=feedforwardnet(3);%建立神经网络，隐层3个节点
net=train(net,xy,z);%训练网络
z1=sim(net,xy);%网络的预测值
figure;t=1:length(z);
plot(t,z,'o',t,z1,'r.')  %画图对比拟合效果
legend('数据','神经网络')
net.layers{1}.transferFcn,net.layers{2}.transferFcn %查看激活函数
net.IW{1},net.LW{2,1},net.b,net.b{1} %查看网络权值


