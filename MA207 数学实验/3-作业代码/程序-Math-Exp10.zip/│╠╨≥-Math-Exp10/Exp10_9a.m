c=[-500,-600];
A=[-1,-1];
b=[-5000];
Aeq=[];
beq=[];
LB=[0;0];
UB=[5000;3000];
[x,fval]=linprog(c,A,b,Aeq,beq,LB,UB);