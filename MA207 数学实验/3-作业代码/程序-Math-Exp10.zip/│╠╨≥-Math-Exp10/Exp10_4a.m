clc,clear
clf,xmin=-5;xmax=3.5;ymin=-3;ymax=5;
x1=linspace(xmin,xmax,30);x2=linspace(ymin,ymax,30);
[X1,X2]=meshgrid(x1,x2);Z= X1.^3.-X2.^3+3*X1.^2+3*X2.^2-9*X1;
contour(X1,X2,Z,60);
colormap jet
hold on,  xp=[-3,1,-3,1];yp=[0 0 2 2];
plot(xp,yp,'ro'),axis([xmin xmax ymin ymax]),colorbar
xlabel('x_1'),ylabel('x_2'),
for i=1:length(xp)
  text(xp(i),yp(i),['\leftarrow (',num2str(xp(i)),',',num2str(yp(i)),')'] )
       end   