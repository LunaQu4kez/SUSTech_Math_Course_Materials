function [f,df1,df2]=Exp10_Fun5a(x1,x2)
%模拟山谷的二次函数程序
 f=100*(x2-x1.^2).^2+(1-x1).^2;       %计算函数值。
 if nargout > 1
   df1=400*(x1.^2-x2).*x1+2*(x1-ones(size(x1)));                %计算梯度向量。
   df2=200*(x2-x1.^2);
end   									