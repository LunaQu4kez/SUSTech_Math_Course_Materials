clf, a=-4;b=4;
xmin=-2;xmax=2;ymin=-20;ymax=20;    %设置变量范围和坐标轴显示范围。
x1=linspace(xmin,xmax,400);x2=linspace(ymin,ymax,400);
[X1,X2]=meshgrid(x1,x2);
[Z,DZ1,DZ2]=Exp10_Fun5a(X1,X2); %计算函数和梯度向量。
contour(X1,X2,Z,50),               %画等值线图。
axis([xmin xmax ymin ymax]),hold on,
axis equal,                              %该命令将使横轴、纵轴具有相同比例，避免失真。
plot([1.46808510638298],[1.148936170212776],'o'),  %标注最优点。
axis([xmin xmax ymin ymax])
x=[];y=[];            %开始用鼠标选点，按左键选点，按右键中止选点过程。
disp('Select a point by put on mouse left-key')
%disp指令,在命令窗口显示文字。
disp('Stop selecting point by put on mouse right-key')
button=1;         %button和ginput命令结合使用可用鼠标选点， 按左键时button＝1。
x=[];y=[];
while button==1
    [xi,yi,button]=ginput(1);
    %ginput(n)用鼠标选n个点，xi,yi分别为点的横坐标和纵坐标。
    plot([xi],[yi],'r.','MarkerSize',10),hold on,             %画所选的点。
    [zi,dz1,dz2]=Exp10_Fun5a(xi,yi);                       %计算函数值和梯度方向。
    v=zi;
    contour(X1,X2,Z,[v v],'-'),             %在点所在的高度画一条等高线。
    axis([xmin xmax ymin ymax]),
    x=[x,xi];y=[y,yi];
    H_line2=plot(x,y);                                  %画已走的路径连线。
    set(H_line2,'color','red','linewidth',2);     %设置颜色和线宽。
    xt=xi-dz1;yt=yi-dz2;
    H_line=plot([xi xt],[yi yt],'k:','linewidth',1);    %画最速下降方向路径。
end           %若按左键button=1，继续循环。若按右键，button~=1,循环终止 。