clc,clear;
x=[0.1,0.2,0.15,0,-0.2,0.3];
y=[0.95,0.84,0.86,1.06,1.50,0.72];
p=polyfit(x,y,2) %二次拟合多项式p(1)x^2+p(2)x+p(3)

xi=-0.2:0.01:0.3;
yi=polyval(p,xi);subplot(2,2,1);
plot(x,y,'o',xi,yi,'k');
title('polyfit');
p=polyfit(x,y,5)%五次拟合多项式(当不超过6个数据点时，                                 
                   %等价于多项式插值)
%p=
%1.0e+003*
%-1.8524 0.7560 0.0079 -0.0275 0.0010 0.0011
yi=polyval(p,xi);subplot(2,2,2);
plot(x,y,'o',xi,yi,'k');
title('polyinterp');
