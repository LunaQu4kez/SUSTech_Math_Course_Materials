function f =Exp8_6fun(x,t)
f=x(1)+x(2)*exp(-0.02*x(3)*t);%x=[a,b,k]
