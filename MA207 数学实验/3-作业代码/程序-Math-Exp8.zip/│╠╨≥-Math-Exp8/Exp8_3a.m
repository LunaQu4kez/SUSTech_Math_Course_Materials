clc,clear
x=[2,3,4,0,2,3,0,1,4]';
y=[2,2,2,3,3,3,4,4,4]';
z=[80,82,84,79,61,65,84,84,86]';
subplot(1,2,1);stem3(x,y,z);title('RAW DATA');
xi=0:0.1:4;yi=[2:0.1:4];[XI,YI]=meshgrid(xi,yi);
ZI=griddata(x,y,z,XI,YI,'cubic');
subplot(1,2,2);mesh(XI,YI,ZI);title('GRIDDATA');
F=scatteredInterpolant(x,y,z);
F(0,2) %求得散乱数据插值函数
%类并求点(0，2)的插值
%ans=
%79.3282
