clc,clear
x=0:2:24;
y=[22,21,19,18,20,24,27,32,31,28,26,23,22];
xi=0:0.1:24;
yi=interp1(x,y,xi,'spline');
plot(xi,yi,'k',x,y,'o');
axis tight
x0=12.75;
y0=interp1(x,y,x0,'spline')
%y0=
%29.0157
%通过计算，午时三刻的温度值约为29℃，该日温度变化曲线图见图。

