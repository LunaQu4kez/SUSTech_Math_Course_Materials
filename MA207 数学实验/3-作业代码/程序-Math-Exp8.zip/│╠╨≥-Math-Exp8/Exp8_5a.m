%以下数据是带随机干扰的正弦曲线.
clear;close;
N=21; %N=201观察效果
x=linspace(0,2*pi,N);
y=sin(x)+(rand(1,N)-0.5)*0.1;
plot(x,y,'o');hold on;fnplt(csape(x,y));%插值结果光滑性不好(见实线).
%而采用拟合
fnplt(csaps(x,y,0.8),'r:');hold off;
%可以清除噪声干扰(见图中虚线).后者不过数据点，不是插值.
