function y=Exp4_6(m)
y=0;
for k=1:m
    t=0;
    con=1;
    while con==1
        ra=rand;
        if ra<(1/3)
            t = t + 3;
            con=0;
        elseif ra<(2/3)
            t = t + 5;
        else
            t = t + 7;
        end
    end
    y = y + t;
end
y = y/m;