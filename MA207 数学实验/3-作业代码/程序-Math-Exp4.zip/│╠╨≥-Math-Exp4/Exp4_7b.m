function [y,a,b,c]=Exp4_7b()
a=rand;
b=rand;
c=rand;
s=a+b+c;
a=a/s;
b=b/s;
c=c/s;
fL=(b)/(b+c)+...
    (c)/(c+a)+...
    (a)/(a+b);
fR=1.5;
y=(fL-fR)/fR;
end
