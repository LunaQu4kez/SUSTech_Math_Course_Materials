N=1e3;
y=zeros(N,1);
n=200+randi(10,1,1);
for k=1:N
    y(k)=Exp4_7(n);
end
plot(y)