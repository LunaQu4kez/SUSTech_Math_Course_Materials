clc,clear
N=1e3;
y=zeros(N,1);
miny=1e100;
for k=1:N
    [y0,a,b,c]=Exp4_7b;
    y(k)=y0;
    if y0<miny
        miny=y0;
        opta=a;
        optb=b;
    end
end
plot(y)