clc,clear
rng('shuffle');
x1=rand
x2=rand
x3=rand
[x1,x2,x3]