function y=Exp4_7(n)
a=rand;
b=rand;
c=rand;
s=a+b+c;
a=a/s;
b=b/s;
c=c/s;
n1=n+1;
fL=(a^n1+b)/(b+c)+...
    (b^n1+c)/(c+a)+...
    (c^n1+a)/(a+b);
fR=(1+3^n)/(2*3^(n-1));
y=(fL-fR)/fR;
end
