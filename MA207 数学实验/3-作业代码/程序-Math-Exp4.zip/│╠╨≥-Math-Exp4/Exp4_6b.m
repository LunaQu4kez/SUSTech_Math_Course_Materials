function y=Exp4_6b(m)
y=0;
a=[3,5,7];
for k=1:m
    con=1;
    b=[];
    while con==1
        ra=randi(3,1,1);
        tmp = find(b==ra, 1);
        if ( ~isempty(tmp) )
            continue;
        end
        if ra==1
            con=0;
        else
            b=[b,ra];
        end
        y = y + a(ra);
    end
end
y = y/m;