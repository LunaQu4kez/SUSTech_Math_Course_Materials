function[ss,er] =Exp9_3b(a,b,n,k)
%X型或Y型二重积分计算
%[a,b]表示定值范围,n表示分割份数,k表示dy=k*dx
%ss表示积分近似值,er表示相对误差
dx=(b-a)/n;
dy=k*dx;
x=a:dx:b;
ss=0;
for i=1:n
    xx=(x(i)+x(i+1))/2;
    y1=x(i)^2;
    y2=x(i);
    yk=y1:dy:y2;
    p=length(yk);
    if p>1
        for j=1:p-1
            yy=(yk(j)+yk(j+1))/2;
            fxy=xx*yy;
            ss=ss+fxy*dx*dy;
        end
    end
end
er=abs(ss-1/24)*24;
