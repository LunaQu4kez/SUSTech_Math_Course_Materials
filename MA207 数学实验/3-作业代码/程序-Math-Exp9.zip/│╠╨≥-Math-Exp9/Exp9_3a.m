function[ss,er]=Exp9_3a(a,b,c,d,m,n)
%矩形域单点柱体法，计算定积分
%[a,b]为积分区域x范围,[c,d]为积分区域y范围，m、n表示分割份数
%ss表示积分近似值,er表示误差
dx=(b-a)/m;
dy=(d-c)/n;
x=a:dx:b;
y=c:dy:d;
ss=0;
for i=1:m
    xx=(x(i)+x(i+1))/2;
    for j=1:n
        yy=(y(j)+y(j+1))/2;
        fxy=xx*yy+yy^3;
        ss=ss+fxy*dx*dy;
    end
end
er=abs(ss -0.5);
