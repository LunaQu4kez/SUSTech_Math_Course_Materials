function y=ExpFun9_4a(x)
y=4./(x.^2+1);
