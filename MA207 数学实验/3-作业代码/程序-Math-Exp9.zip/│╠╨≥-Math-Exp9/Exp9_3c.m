function ss=Exp9_3c(a,b,n,k)
dx=(b-a)/n;
dy=k*dx;
x=a:dx:b;
ss=0;
for i=1:n
    xx=(x(i)+x(i+1))/2;
    y1=x(i)^2;
    y2=2*x(i);
    yk=y1:dy:y2;
    p=length(yk);
    if p>1
        for j=1:p-1
            yy=(yk(j)+yk(j+1))/2;
            fxy=sin((3*xx+yy)/5)*exp(-xx*xx-xx*yy);
            ss=ss+fxy*dx*dy;
        end
    end
end
