function f=ExpFun9_4d(x)
f=exp(-x.^2).*sin(x);
