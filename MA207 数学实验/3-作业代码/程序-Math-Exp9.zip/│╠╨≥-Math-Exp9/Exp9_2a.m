function [ss,er]=Exp9_2a(t,a,b,n)
%t用于控制积分方法,[a,b]为对应积分区间,n表示分割份数
%ss表示积分近似值,er表示误差
dx=(b-a)/n;
syms x;
ff=1/(1+x^2);
xx=a:dx:b;
ss=0;
if t==1 %左矩形法
    for i=1:n
        f1=subs(ff,x,xx(i));
        ss=ss+dx*f1;
    end
elseif t==2  %右矩形法
    for i=1:n
        f1 =subs(ff,x,xx(i+1));
        ss=ss+dx*f1;
    end
elseif t==3  %中矩形法
    for i=1:n
        yy=(xx(i)+xx(i+1))/2;
        f1=subs(ff,x,yy);
        ss=ss+dx*f1;
    end
elseif t==4  %梯形法
    for i=1:n
        f1=subs(ff,x,xx(i));
        f2=subs(ff,x,xx(i+1));
        ss=ss+dx*(f1+f2)/2;
    end
else  %辛普生方法
    for i=1:n
        f1=subs(ff,x,xx(i));
        f2=subs(ff,x,xx(i+1));
        yy=(xx(i)+xx(i+1))/2;
        f12=subs(ff,x,yy);
        ss=ss+dx*(f1+f2+4*f12)/6;
    end
end
ss=vpa(ss);
er=abs(ss-pi/4);
er=vpa(er);

