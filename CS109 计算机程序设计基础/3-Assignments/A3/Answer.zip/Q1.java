import java.util.Arrays;
import java.util.Scanner;

public class Q1 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int[] rt = new int[n];
        int[] rl = new int[n];
        int[] ra = new int[n];
        int[] ct = new int[n];
        int[] cl = new int[n];
        int[] ca = new int[n];
        int indexRT = 0;
        int indexRL = 0;
        int indexRA = 0;
        int indexCT = 0;
        int indexCL = 0;
        int indexCA = 0;
        in.nextLine();
        while (n-- > 0) {
            String line = in.nextLine();
            String[] elements = line.split(",");
            if (elements[0].equals("R")) {
                if (elements[1].equals("theory")) {
                    rt[indexRT++] = Integer.parseInt(elements[2]);
                } else if (elements[1].equals("lab")) {
                    rl[indexRL++] = Integer.parseInt(elements[2]);
                } else {
                    ra[indexRA++] = Integer.parseInt(elements[2]);
                }
            } else {
                if (elements[1].equals("theory")) {
                    ct[indexCT++] = Integer.parseInt(elements[2]);
                } else if (elements[1].equals("lab")) {
                    cl[indexCL++] = Integer.parseInt(elements[2]);
                } else {
                    ca[indexCA++] = Integer.parseInt(elements[2]);
                }
            }
        }
        rt = orderArray(rt, indexRT);
        ct = orderArray(ct, indexCT);
        rl = orderArray(rl, indexRL);
        cl = orderArray(cl, indexCL);
        ra = orderArray(ra, indexRA);
        ca = orderArray(ca, indexCA);
        if (compare(rt, ct)&&compare(rl,cl)&&compare(ra,ca)) {
            System.out.println("Yes");
        }else{
            System.out.println("No");
        }


    }

    static boolean compare(int[] room, int[] course) {
        int roomLength = room.length;
        int courseLength = course.length;
        if (roomLength < course.length)
            return false;
        int index = 0;
        for (int i = 0; i < course.length; i++) {
            if (room[i] < course[i])
                return false;
        }
        return true;
    }

    static int[] orderArray(int[] array, int index) {
        int[] newArr = Arrays.copyOf(array, index);
        for (int i = 0; i < newArr.length - 1; i++) {
            for (int j = 0; j < newArr.length - 1 - i; j++) {
                if (newArr[j] < newArr[j + 1]) {
                    int temp = newArr[j];
                    newArr[j] = newArr[j + 1];
                    newArr[j + 1] = temp;
                }
            }
        }
        return newArr;
    }
}
