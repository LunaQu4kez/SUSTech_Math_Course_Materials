import java.util.Arrays;
import java.util.Scanner;

public class Q2 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String str = in.next();
        int k = in.nextInt();
        String[] parts = divideString(str, k);
        long sum = 0;
        for (String part : parts) {
            sum += Long.parseLong(part);
        }
        System.out.println(sum);
    }

    public static String[] divideString(String str, int k) {
        StringBuilder sb = new StringBuilder();
        int length = str.length() / k;
        if (str.length() % k != 0)
            length++;
        String[] parts = new String[length];
        for (int i = 0; i < parts.length - 1; i++) {
            sb.setLength(0);
            sb.append(str, i * k, i * k + k);
            parts[i] = sb.reverse().toString();
        }
        sb.setLength(0);
        parts[length - 1] = sb.append(str.substring(k * (length - 1))).reverse().toString();
        return parts;
    }
}
