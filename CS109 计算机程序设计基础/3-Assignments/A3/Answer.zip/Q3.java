import java.util.Scanner;

/*
5 8
0 1 2 3 4 5 6 7
8 9 10 11 12 13 14 15
16 17 18 19 20 21 22 23
24 25 26 27 28 29 30 31
32 33 34 35 36 37 38 39
26 5
 */
public class Q3 {
    static int row;
    static int col;

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        row = in.nextInt();
        col = in.nextInt();
        int[][] matrix = new int[row][col];
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                matrix[i][j] = in.nextInt();
            }
        }
        int num = in.nextInt();
        int k = in.nextInt();
        int r = 0, c = 0;
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                if (matrix[i][j] == num) {
                    r = i;
                    c = j;
                    break;
                }
            }
        }
        int target = findTarget(k, matrix, r, c);
        System.out.println(target);

    }

    private static int findTarget(int k, int[][] matrix, int r, int c) {
        Direction[] directions = new Direction[4];
        directions[0] = new Direction(0, 1); //right
        directions[1] = new Direction(1, 0); //down
        directions[2] = new Direction(0, -1); //left
        directions[3] = new Direction(-1, 0); //up
        int step = 0;
        int index = 0;
        int v = 0;
        if (k == 0) {
            return matrix[r][c];
        }
        while (true) {
            if (index % 2 == 0)
                v++;
            for (int i = 0; i < v; i++) {
                r = r + directions[index].dr;
                c = c + directions[index].dc;
                if (canVisit(r, c)) {
                    step++;
                    if (step == k) {
                        return matrix[r][c];
                    }
                }
            }
            index += 1;
            if (index == 4)
                index = 0;
        }
    }

    private static boolean canVisit(int r, int c) {
        return r >= 0 && r < row && c >= 0 && c < col;
    }

}

class Direction {
    int dr, dc;

    public Direction(int dr, int dc) {
        this.dr = dr;
        this.dc = dc;
    }
}
