

import java.util.Scanner;

public class Answer2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int testCases = scanner.nextInt();

        for (int i = 0; i < testCases; i++) {
            int start = scanner.nextInt();
            int end = scanner.nextInt();

            // Initialize a counter to count the numbers that meet the conditions
            int count = 0;

            // Iterate through each number in the range
            for (int num = start; num <= end; num++) {
                // Check if the current number is divisible by 7 or contains the digit 7
                if (num % 7 == 0 || String.valueOf(num).contains("7")) {
                    // If the condition is met, increment the counter
                    count++;
                }
            }

            System.out.println(count);
        }

        scanner.close();
    }
}
