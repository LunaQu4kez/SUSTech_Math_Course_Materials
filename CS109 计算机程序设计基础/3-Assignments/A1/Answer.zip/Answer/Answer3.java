

import java.util.Scanner;

public class Answer3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int testCases = scanner.nextInt();

        for (int i = 0; i < testCases; i++) {
            int decimal = scanner.nextInt();
            String septenary = decimalToSeptenary(decimal);
            System.out.println(septenary);
        }

        scanner.close();
    }

    /**
     * Convert a decimal integer to its septenary (base-7) representation.
     *
     * @param decimal the decimal integer to convert
     * @return the septenary representation as a string
     */
    public static String decimalToSeptenary(int decimal) {
        // If the decimal integer is 0, return "0" directly
        if (decimal == 0)
            return "0";

        String septenary = "";

        // Convert decimal to septenary using division and remainder
        while (decimal > 0) {
            int remainder = decimal % 7;
            septenary = remainder + septenary; // Prepend the remainder to the septenary representation
            decimal /= 7; // Update decimal by dividing by 7
        }

        return septenary;
    }
}
