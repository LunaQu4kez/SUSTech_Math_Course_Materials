

import java.util.Scanner;

public class Answer1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int numCases = scanner.nextInt();

        for (int i = 0; i < numCases; i++) {
            // Read input for the current test case
            int currentYear = scanner.nextInt();
            int currentMonth = scanner.nextInt();
            int currentDay = scanner.nextInt();
            int summerStartYear = scanner.nextInt();
            int summerStartMonth = scanner.nextInt();
            int summerStartDay = scanner.nextInt();

            // Calculate the number of days until summer vacation
            int days = calculateDaysUntilSummer(currentYear, currentMonth, currentDay, summerStartYear, summerStartMonth, summerStartDay);

            System.out.println(days);
        }

        scanner.close();
    }

    // Function to calculate the number of days until summer vacation
    public static int calculateDaysUntilSummer(int currentYear, int currentMonth, int currentDay, int summerStartYear, int summerStartMonth, int summerStartDay) {
        int totalDays = 0;

        // Loop until the current date matches the start of summer vacation
        while (currentYear != summerStartYear || currentMonth != summerStartMonth || currentDay != summerStartDay) {
            totalDays++; // Increment total days

            // Increment the current day
            currentDay++;

            // Get the number of days in the current month
            int daysInMonth = getDaysInMonth(currentYear, currentMonth);

            // Check if the current day exceeds the number of days in the current month
            if (currentDay > daysInMonth) {
                currentDay = 1; // Reset current day to 1
                currentMonth++; // Move to the next month

                // Check if the current month exceeds 15 (the maximum number of months)
                if (currentMonth > 15) {
                    currentMonth = 1; // Reset current month to 1
                    currentYear++; // Move to the next year
                }
            }
        }

        return totalDays; // Return the total number of days
    }

    // Function to get the number of days in a month
    public static int getDaysInMonth(int year, int month) {
        // Check if the month is May or March in a leap year
        if (month == 5 || (month == 3 && isLeapYear(year))) {
            return 62; // May and leap year March have 62 days
        } else {
            return 61; // Other months have 61 days
        }
    }

    // Function to check if a year is a leap year
    public static boolean isLeapYear(int year) {
        return year % 13 == 0; // Years divisible by 13 are leap years
    }
}
