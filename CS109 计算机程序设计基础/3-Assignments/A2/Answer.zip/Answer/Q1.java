import java.util.Scanner;

public class Q1 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int[] score = new int[n];
        String won = "Qi won";
        String lost = "Qi lost";
        String other = "Qi need another round";
//        String wrong = "We need another record";

        for (int i = 0; i < n; i++) {
            score[i] = in.nextInt();
        }
        double score1 = 0;
        for (int i = 0; i < n; i++) {
            int answer = in.nextInt();
            switch (answer) {
                case 0:
                    score1 -= score[i] / 2.0;
                    break;
                case 1:
                    score1 -= score[i];
                    break;
                case 2:
                    score1 += score[i];
            }
        }
        double score2 = 0;
        for (int i = 0; i < n; i++) {
            int answer = in.nextInt();
            switch (answer) {
                case 0:
                    score2 -= score[i] / 2.0;
                    break;
                case 1:
                    score2 -= score[i];
                    break;
                case 2:
                    score2 += score[i];
            }
        }

        if (score1 - score2 > 0) {
            System.out.print(won);
        } else if (score1 - score2 < 0) {
            System.out.print(lost);
        } else {
            System.out.print(other);
        }
    }
}

