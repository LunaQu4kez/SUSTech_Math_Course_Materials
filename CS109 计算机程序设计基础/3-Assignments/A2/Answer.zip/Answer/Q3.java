import java.util.Scanner;

public class Q3 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int target = in.nextInt();
        int row = in.nextInt();
        int col = in.nextInt();
        int[][] m = new int[row + 2][col + 2];
        for (int i = 1; i <= row; i++) {
            for (int j = 1; j <= col; j++) {
                m[i][j] = in.nextInt();
            }
        }
        for (int i = 1; i <= row; i++) {
            for (int j = 1; j <= col; j++) {
                if (m[i][j] == 1) {
                    if (m[i - 1][j] != 1)
                        m[i - 1][j] = 2;
                    if (m[i + 1][j] != 1)
                        m[i + 1][j] = 2;
                }
            }
        }

        int resource = 0;
        for (int i = 1; i <= row; i++) {
            for (int j = 1; j <= col; j++) {
                if (m[i][j] == 0) {
                    m[i][j] = 3;
                    resource++;
                    if (m[i - 1][j] != 1)
                        m[i - 1][j] = 2;
                    if (m[i + 1][j] != 1)
                        m[i + 1][j] = 2;
                }
            }
        }

        System.out.println((resource - target >= 0) ? "True" : "False");
    }

}
