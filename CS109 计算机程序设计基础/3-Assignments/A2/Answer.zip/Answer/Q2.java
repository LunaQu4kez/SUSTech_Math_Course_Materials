import java.util.Scanner;

public class Q2 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n1 = in.nextInt();
        int[] m1 = new int[n1];
        for (int i = 0; i < n1; i++) {
            m1[i] = in.nextInt();
        }
        int n2 = in.nextInt();
        int[] m2 = new int[n2];
        for (int i = 0; i < n2; i++) {
            m2[i] = in.nextInt();
        }
        int length = Math.min(n1, n2);
        int[] same = new int[length];
        int index = 0;
        for (int i = 0; i < n1; i++) {
            for (int j = 0; j < n2; j++) {
                if (m1[i] == m2[j]) {
                    same[index] = m1[i];
                    index++;
                }
            }
        }
        int n3 = in.nextInt();
        int[] m3 = new int[n3];
        for (int i = 0; i < n3; i++) {
            m3[i] = in.nextInt();
        }
        index = 0;
        for (int k : same) {
            for (int j = 0; j < n3; j++) {
                if (k == m3[j]) {
                    index++;
                }
            }
        }
        System.out.println(index);

    }
}
