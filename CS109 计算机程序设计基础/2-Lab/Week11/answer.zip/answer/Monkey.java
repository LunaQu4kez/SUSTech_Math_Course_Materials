public class Monkey extends Animal {
    @Override
    public void speak() {
        System.out.println("aaaa");
    }
}
