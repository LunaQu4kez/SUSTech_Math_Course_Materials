public class Human extends Animal{
    @Override
    public void speak() {
        System.out.println("Hello World!");
    }
}
