import java.io.*;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class GobangChess {
    int[][] chessboard;

    public int[][] getChessboard() {
        return chessboard;
    }

    public void convertToChessboard(List<String> readlines) {
        this.chessboard = new int[readlines.size()][];

        for (int i = 0; i < readlines.size(); i++) {
            String[] pieces = readlines.get(i).split(",");
            this.chessboard[i] = new int[pieces.length];
            for (int j = 0; j < pieces.length; j++) {
                this.chessboard[i][j] = Integer.parseInt(pieces[j]);
            }
        }
    }

    public void playing(int x, int y, int player) {
        this.chessboard[x][y] = player;
    }

    public List<String> convertToList() {
        List<String> lines = new ArrayList<>();
        StringBuilder sb = new StringBuilder();
        for (int[] ints : this.chessboard) {
            sb.setLength(0);
            for (int anInt : ints) {
                sb.append(anInt).append(",");
            }
            sb.setLength(sb.length() - 1);
            lines.add(sb.toString());
        }
        return lines;
    }

    public void printChessboard() {
        for (int[] l : chessboard) {
            System.out.println(Arrays.toString(l));
        }
    }


}
