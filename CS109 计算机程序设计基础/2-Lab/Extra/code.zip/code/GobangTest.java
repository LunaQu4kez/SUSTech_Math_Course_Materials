
import java.util.List;

public class GobangTest {
    public static void main(String[] args) {
        GobangChess gobangChess = new GobangChess();
        FileUtil fileUtil = new AdvancedFileUtil();
        List<String> lines = fileUtil.readFileToList("chessboard.txt");
        gobangChess.convertToChessboard(lines);

        gobangChess.printChessboard();

        gobangChess.playing(4, 3, 1);
        gobangChess.playing(2, 3, 2);

        gobangChess.printChessboard();

        fileUtil.writeFileFromList("chessboard_new.txt", gobangChess.convertToList());
    }
}
