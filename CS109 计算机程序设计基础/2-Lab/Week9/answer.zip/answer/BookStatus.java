

public enum BookStatus {
    IDLE, BORROWED, OVERDUE;
}
